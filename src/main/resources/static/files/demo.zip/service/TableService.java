package com.example.demo.service;

import com.example.demo.dao.TableDao;
import com.example.demo.entity.Table;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@MapperScan(value="com.example.demo.dao")
public class TableService {
    @Autowired
    private TableDao tableDao;

    public List<Table> getTableByBatch(String batchname){
        return tableDao.getTableByBatch(batchname);
    }
}
