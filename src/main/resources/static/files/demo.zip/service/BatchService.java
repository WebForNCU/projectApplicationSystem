package com.example.demo.service;

import com.example.demo.dao.BatchDao;
import com.example.demo.entity.Batch;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@MapperScan(value = "com.example.demo.dao")
public class BatchService {
    @Autowired
    private BatchDao batchDao;

    public List<Batch> getBatchList(){
        return batchDao.batchList();
    }
}
