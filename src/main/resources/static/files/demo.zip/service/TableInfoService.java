package com.example.demo.service;

import com.example.demo.dao.TableInfoDao;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
@MapperScan(value="com.example.demo.dao")
public class TableInfoService {
    @Autowired
    private TableInfoDao tableInfoDao;

    public List<Map> findAllInfo(String batchname){
        return tableInfoDao.findAllInfo(batchname);
    }
    public List<Map> findUnAudited(String batchname1){return tableInfoDao.findUnAudited(batchname1);}
    
}
