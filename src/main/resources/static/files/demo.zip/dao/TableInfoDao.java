package com.example.demo.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
@Mapper
public interface TableInfoDao {
    List<Map> findAllInfo(@Param("batchname")String batchname);
    List<Map> findUnAudited(@Param("batchname1")String batchname1);

    void update(@Param("batchname") String batchname,@Param("projectname") String projectname);
}
