package com.example.demo.controller;

import com.example.demo.entity.Batch;
import com.example.demo.service.BatchService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@Controller
@RequestMapping(value = "/batch")
public class BatchController {
    @Autowired
    private BatchService batchService;
    @Autowired
    private BatchService batchService1;
    @RequestMapping("/batchlist")
    @ResponseBody
    public String getBatchList(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setHeader("Content-Type","text/html;charset=utf-8");
        List<Batch> batchList = batchService.getBatchList();
        PrintWriter out = response.getWriter();
        ObjectMapper mapper = new ObjectMapper();
        String jsonStr = mapper.writeValueAsString(batchList);
        out.println(jsonStr);
        out.flush();
        out.close();
        return jsonStr;
    }
    @RequestMapping("/batchlist1")
    @ResponseBody
    public String getBatchList1(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setHeader("Content-Type","text/html;charset=utf-8");
        List<Batch> batchList = batchService1.getBatchList();
        PrintWriter out = response.getWriter();
        ObjectMapper mapper = new ObjectMapper();
        String jsonStr = mapper.writeValueAsString(batchList);
        out.println(jsonStr);
        out.flush();
        out.close();
        return jsonStr;
    }
}
