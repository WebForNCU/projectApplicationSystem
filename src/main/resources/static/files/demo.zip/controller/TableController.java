package com.example.demo.controller;

import com.example.demo.entity.Table;
import com.example.demo.service.TableService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@Controller
@RequestMapping("table")
public class TableController {
    @Autowired
    private TableService tableService;
    @RequestMapping("batch")
    @ResponseBody
    public String getTableByBatch(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String batchname = request.getParameter("batchname");
        List<Table> tableList = tableService.getTableByBatch(batchname);
        response.setHeader("Content-Type","text/html;charset=utf-8");
        Object mapper = new ObjectMapper();
        String jsonStr = ((ObjectMapper) mapper).writeValueAsString(tableList);
        PrintWriter out = response.getWriter();
        out.println(jsonStr);
        out.flush();
        out.close();
        return jsonStr;
    }

}
