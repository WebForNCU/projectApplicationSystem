package com.example.demo.controller;

import com.example.demo.service.TableInfoService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Controller
@RequestMapping("table")
public class TableInfoController {
    @Autowired
    private TableInfoService tableInfoService;
    @RequestMapping("tableinfo")
    @ResponseBody
    public String findAllInfo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String batchname = request.getParameter("batchname");
        List<Map> tableInfo = tableInfoService.findAllInfo(batchname);
        response.setHeader("Content-Type","text/html;charset=utf-8");
        Object mapper = new ObjectMapper();
        String jsonStr = ((ObjectMapper) mapper).writeValueAsString(tableInfo);
        PrintWriter out = response.getWriter();
        out.println(jsonStr);
        out.flush();
        out.close();
        return jsonStr;
    }
    @RequestMapping("unauditedinfo")
    @ResponseBody
    public String findUnAuditedInfo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String batchname1 = request.getParameter("batchname1");
        List<Map> info = tableInfoService.findUnAudited(batchname1);
        response.setHeader("Content-Type","text/html;charset=utf-8");
        Object mapper = new ObjectMapper();
        String jsonStr = ((ObjectMapper) mapper).writeValueAsString(info);
        PrintWriter out = response.getWriter();
        out.println(jsonStr);
        out.flush();
        out.close();
        return jsonStr;
    }

    public void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String batchname = request.getParameter("batchname");
        String projectname = request.getParameter("projectname");

    }
}
